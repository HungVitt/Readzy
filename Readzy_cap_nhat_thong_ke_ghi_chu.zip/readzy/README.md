# Readzy - Hệ thống quản lý thư viện cá nhân (Laravel)

Mã nguồn này chứa toàn bộ phần logic riêng của dự án Readzy (models, controllers,
migrations, routes, views) được viết theo chuẩn Laravel 11. Vì môi trường tạo ra
mã nguồn này không có quyền truy cập Packagist để tải Laravel framework qua Composer,
bạn cần cài đặt Composer dependencies ở máy của bạn theo các bước dưới đây.

## 1. Yêu cầu môi trường
- PHP >= 8.2
- Composer
- MySQL (hoặc MariaDB)
- (Tuỳ chọn) Node.js nếu muốn build thêm asset, nhưng dự án này dùng Tailwind qua CDN nên không bắt buộc.

## 2. Cài đặt

```bash
# 1. Giải nén rồi vào thư mục dự án
cd readzy

# 2. Cài Laravel framework + các gói cần thiết
composer install

# 3. Tạo file .env từ mẫu và sinh APP_KEY
cp .env.example .env
php artisan key:generate

# 4. Cấu hình database trong file .env
#    DB_DATABASE=readzy
#    DB_USERNAME=root
#    DB_PASSWORD=...
#    (nhớ tạo database "readzy" trong MySQL trước)

# 5. Chạy migration + seed dữ liệu mẫu (tài khoản admin/user demo + vài sách)
php artisan migrate --seed

# 6. Tạo symlink cho ảnh bìa sách (upload lưu trong storage/app/public)
php artisan storage:link

# 7. Chạy thử
php artisan serve
```

Truy cập: http://localhost:8000

## 3. Tài khoản demo (do seeder tạo)
| Vai trò | Email | Mật khẩu |
|---|---|---|
| Admin | admin@readzy.local | password |
| User | user@readzy.local | password |

## 4. Luồng chức năng đã hiện thực

**Khách (chưa đăng nhập):**
- Xem trang chủ, danh sách sách đã được duyệt, tìm kiếm theo tên/tác giả, lọc theo thể loại
- Xem trang chi tiết sách
- Phải đăng nhập mới đọc được nội dung

**User (đăng ký/đăng nhập):**
- Đăng ký xong vào thẳng hệ thống, không cần chờ duyệt
- Xem & đọc truyện đã được duyệt (đọc theo từng "trang", có nút Trang trước/Trang sau)
- Hệ thống tự lưu lại trang đang đọc (bảng `reading_progress`) — vào lại là đọc tiếp đúng chỗ cũ
- Gửi truyện mới lên hệ thống → trạng thái "Chờ phê duyệt"
- Xem trang "Truyện của tôi" để theo dõi trạng thái: Chờ phê duyệt / Đã phê duyệt / Từ chối (kèm lý do nếu bị từ chối)

**Admin:**
- Dashboard thống kê tổng số sách, số đang chờ duyệt, số user, số thể loại...
- Quản lý toàn bộ sách: thêm/sửa/xóa, lọc theo trạng thái, tìm kiếm
- Phê duyệt hoặc từ chối (kèm lý do) truyện do user gửi — chỉ sách đã duyệt mới hiển thị công khai
- Quản lý thể loại (thêm/sửa/xóa)

## 5. Cấu trúc thư mục chính
```
app/Models/                Book, Category, User, ReadingProgress
app/Http/Controllers/      BookController, ReadingController, Auth/*, Admin/*
app/Http/Middleware/       EnsureUserIsAdmin.php (alias: 'admin')
database/migrations/       users, categories, books, reading_progress
database/seeders/          DatabaseSeeder.php (tài khoản + dữ liệu mẫu)
resources/views/           layouts, auth, books, admin
routes/web.php             toàn bộ route của hệ thống
```

## 6. Một vài điểm có thể mở rộng thêm sau này
- Đổi cách lưu nội dung truyện sang từng "chương" (bảng `chapters`) thay vì 1 cột `content` dài
- Thêm phân trang server-side thật (hiện tại chia trang theo số ký tự để demo)
- Thêm chức năng bình luận, đánh giá sao cho từng truyện
- Thêm email thông báo khi truyện được duyệt/từ chối

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Readzy - Thư viện cá nhân')</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen flex flex-col">

    <nav class="bg-indigo-700 text-white shadow">
        <div class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
            <a href="{{ route('books.index') }}" class="text-xl font-bold tracking-wide">📚 Readzy</a>

            <div class="flex items-center gap-4 text-sm">
                <a href="{{ route('books.index') }}" class="hover:text-indigo-200">Trang chủ</a>

                @auth
                    <a href="{{ route('books.create') }}" class="hover:text-indigo-200">Gửi truyện</a>
                    <a href="{{ route('books.my') }}" class="hover:text-indigo-200">Truyện của tôi</a>
                    <a href="{{ route('reading.personal') }}" class="hover:text-indigo-200">Thống kê & ghi chú</a>

                    @if(auth()->user()->isAdmin())
                        <a href="{{ route('admin.dashboard') }}" class="bg-indigo-500 px-3 py-1 rounded hover:bg-indigo-400">Quản trị</a>
                    @endif

                    <span class="text-indigo-200">Xin chào, {{ auth()->user()->name }}</span>
                    <form action="{{ route('logout') }}" method="POST">
                        @csrf
                        <button class="hover:text-indigo-200">Đăng xuất</button>
                    </form>
                @else
                    <a href="{{ route('login') }}" class="hover:text-indigo-200">Đăng nhập</a>
                    <a href="{{ route('register') }}" class="bg-white text-indigo-700 px-3 py-1 rounded font-medium hover:bg-indigo-100">Đăng ký</a>
                @endauth
            </div>
        </div>
    </nav>

    <main class="flex-1 max-w-6xl w-full mx-auto px-4 py-8">
        @if(session('success'))
            <div class="mb-4 rounded bg-green-100 text-green-800 px-4 py-3 text-sm">
                {{ session('success') }}
            </div>
        @endif
        @if(session('error'))
            <div class="mb-4 rounded bg-red-100 text-red-800 px-4 py-3 text-sm">
                {{ session('error') }}
            </div>
        @endif

        @yield('content')
    </main>

    <footer class="bg-white border-t text-center text-sm text-slate-500 py-4">
        &copy; {{ date('Y') }} Readzy - Hệ thống quản lý thư viện cá nhân.
    </footer>
</body>
</html>

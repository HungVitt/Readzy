@extends('layouts.app')
@section('title', 'Readzy - Thư viện cá nhân')

@section('content')
<div class="mb-6">
    <h1 class="text-3xl font-bold mb-4">Thư viện Readzy 📖</h1>

    <form method="GET" action="{{ route('books.index') }}" class="flex flex-wrap gap-3">
        <input type="text" name="q" value="{{ request('q') }}" placeholder="Tìm theo tên sách hoặc tác giả..."
               class="flex-1 min-w-[200px] border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">

        <select name="category" class="border rounded px-3 py-2">
            <option value="">Tất cả thể loại</option>
            @foreach($categories as $cat)
                <option value="{{ $cat->id }}" @selected(request('category') == $cat->id)>{{ $cat->name }}</option>
            @endforeach
        </select>

        <button type="submit" class="bg-indigo-600 text-white px-5 py-2 rounded hover:bg-indigo-700">
            Tìm kiếm
        </button>
    </form>
</div>

<div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-5">
    @forelse($books as $book)
        <a href="{{ route('books.show', $book) }}" class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden flex flex-col">
            <div class="h-48 bg-slate-200 flex items-center justify-center">
                @if($book->cover_path)
                    <img src="{{ asset('storage/' . $book->cover_path) }}" class="h-full w-full object-cover" alt="{{ $book->title }}">
                @else
                    <span class="text-4xl">📕</span>
                @endif
            </div>
            <div class="p-3 flex-1 flex flex-col">
                <h2 class="font-semibold text-sm line-clamp-2">{{ $book->title }}</h2>
                <p class="text-xs text-slate-500 mt-1">{{ $book->author ?: 'Chưa rõ tác giả' }}</p>
                @if($book->category)
                    <span class="mt-auto text-xs inline-block bg-indigo-50 text-indigo-600 px-2 py-1 rounded self-start mt-2">
                        {{ $book->category->name }}
                    </span>
                @endif
            </div>
        </a>
    @empty
        <p class="col-span-full text-center text-slate-500 py-10">Chưa có truyện nào phù hợp.</p>
    @endforelse
</div>

<div class="mt-8">
    {{ $books->links() }}
</div>
@endsection

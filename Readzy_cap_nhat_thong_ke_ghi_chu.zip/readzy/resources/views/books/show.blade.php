@extends('layouts.app')
@section('title', $book->title . ' - Readzy')

@section('content')
<div class="bg-white rounded-lg shadow p-6 flex flex-col md:flex-row gap-6">
    <div class="w-full md:w-56 h-72 bg-slate-200 rounded flex items-center justify-center shrink-0">
        @if($book->cover_path)
            <img src="{{ asset('storage/' . $book->cover_path) }}" class="h-full w-full object-cover rounded" alt="{{ $book->title }}">
        @else
            <span class="text-6xl">📕</span>
        @endif
    </div>

    <div class="flex-1">
        <h1 class="text-2xl font-bold">{{ $book->title }}</h1>
        <p class="text-slate-500 mt-1">Tác giả: {{ $book->author ?: 'Chưa rõ' }}</p>

        @if($book->category)
            <span class="inline-block mt-2 text-xs bg-indigo-50 text-indigo-600 px-2 py-1 rounded">
                {{ $book->category->name }}
            </span>
        @endif

        @if($book->status !== 'approved')
            <span class="inline-block mt-2 ml-2 text-xs px-2 py-1 rounded
                {{ $book->status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700' }}">
                {{ $book->status === 'pending' ? 'Chờ phê duyệt' : 'Bị từ chối' }}
            </span>
        @endif

        <div class="mt-3 text-sm text-amber-600">★ {{ $averageRating ?: 'Chưa có' }} / 5 <span class="text-slate-500">({{ $book->reviews->count() }} đánh giá)</span></div>
        <p class="mt-4 text-slate-700 whitespace-pre-line">{{ $book->description ?: 'Chưa có mô tả cho truyện này.' }}</p>

        @if($book->story_file_path)
            <a class="inline-block mt-4 text-indigo-600 underline" href="{{ asset('storage/' . $book->story_file_path) }}" target="_blank" rel="noopener">Mở/tải tệp truyện (Word/PDF)</a>
        @endif
        <div class="mt-6 flex items-center gap-3">
            @auth
                <a href="{{ route('books.read', $book) }}"
                   class="bg-indigo-600 text-white px-5 py-2 rounded hover:bg-indigo-700">
                    {{ $progress ? 'Đọc tiếp (trang ' . $progress->current_page . '/' . $book->total_pages . ')' : 'Bắt đầu đọc' }}
                </a>
            @else
                <a href="{{ route('login') }}" class="bg-indigo-600 text-white px-5 py-2 rounded hover:bg-indigo-700">
                    Đăng nhập để đọc
                </a>
            @endauth
        </div>
    </div>
</div>

@if($book->status === 'approved')
<section class="mt-6 bg-white rounded-lg shadow p-6">
    <h2 class="text-xl font-bold mb-3">Đánh giá & bình luận</h2>
    @auth
    <form method="POST" action="{{ route('books.reviews.store', $book) }}" class="space-y-3 mb-6">
        @csrf
        <label class="block text-sm font-medium">Bạn đánh giá mấy sao?</label>
        <select name="rating" required class="border rounded px-3 py-2">
            @for($i=5;$i>=1;$i--)
                <option value="{{ $i }}" @selected(old('rating', $myReview->rating ?? 5)==$i)>{{ str_repeat('★', $i) }} ({{ $i }} sao)</option>
            @endfor
        </select>
        <textarea name="comment" rows="3" maxlength="2000" placeholder="Viết bình luận của bạn (không bắt buộc)" class="w-full border rounded px-3 py-2">{{ old('comment', $myReview->comment ?? '') }}</textarea>
        <button class="bg-indigo-600 text-white px-5 py-2 rounded">{{ $myReview ? 'Cập nhật đánh giá' : 'Gửi đánh giá' }}</button>
    </form>
    @else
        <p class="mb-4 text-sm text-slate-600"><a href="{{ route('login') }}" class="text-indigo-600 underline">Đăng nhập</a> để đánh giá và bình luận.</p>
    @endauth
    @forelse($book->reviews->sortByDesc('created_at') as $review)
        <div class="border-t py-3">
            <div class="font-medium">{{ $review->user->name }} <span class="text-amber-500">{{ str_repeat('★', $review->rating) }}{{ str_repeat('☆', 5-$review->rating) }}</span></div>
            @if($review->comment)<p class="text-slate-700 mt-1 whitespace-pre-line">{{ $review->comment }}</p>@endif
            <p class="text-xs text-slate-400 mt-1">{{ $review->created_at->format('d/m/Y') }}</p>
        </div>
    @empty
        <p class="text-sm text-slate-500">Chưa có đánh giá nào.</p>
    @endforelse
</section>
@endif
@endsection

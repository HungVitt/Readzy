@extends('layouts.app')
@section('title', 'Gửi truyện mới - Readzy')

@section('content')
<div class="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow">
    <h1 class="text-2xl font-bold mb-6">Gửi truyện mới</h1>

    @if ($errors->any())
        <div class="mb-4 rounded bg-red-100 text-red-700 px-4 py-3 text-sm">
            @foreach ($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <p class="mb-4 text-sm text-slate-500">
        Truyện của bạn sẽ ở trạng thái <strong>Chờ phê duyệt</strong> và chỉ hiển thị công khai sau khi Admin duyệt.
    </p>

    <form method="POST" action="{{ route('books.store') }}" enctype="multipart/form-data" class="space-y-4">
        @csrf
        <div>
            <label class="block text-sm font-medium mb-1">Tên truyện</label>
            <input type="text" name="title" value="{{ old('title') }}" required
                   class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Tác giả</label>
            <input type="text" name="author" value="{{ old('author') }}"
                   class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Thể loại</label>
            <select name="category_id" class="w-full border rounded px-3 py-2">
                <option value="">-- Chọn thể loại --</option>
                @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" @selected(old('category_id') == $cat->id)>{{ $cat->name }}</option>
                @endforeach
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Ảnh bìa (tùy chọn)</label>
            <input type="file" name="cover" accept="image/*" class="w-full border rounded px-3 py-2">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Mô tả ngắn</label>
            <textarea name="description" rows="3" class="w-full border rounded px-3 py-2">{{ old('description') }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Nội dung truyện</label>
            <textarea name="content" rows="10"
                      class="w-full border rounded px-3 py-2">{{ old('content') }}</textarea>
            <p class="text-xs text-slate-500 mt-1">Có thể dán nội dung truyện hoặc tải lên tệp Word/PDF bên dưới (tối đa 20 MB).</p>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Tệp truyện (Word hoặc PDF)</label>
            <input type="file" name="story_file" accept=".doc,.docx,.pdf,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" class="w-full border rounded px-3 py-2">
            @error('story_file') <p class="text-sm text-red-600 mt-1">{{ $message }}</p> @enderror
        </div>

        <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700">
            Gửi cho Admin duyệt
        </button>
    </form>
</div>
@endsection

@extends('layouts.app')
@section('title','Thống kê đọc sách của tôi')
@section('content')
<div class="max-w-5xl mx-auto space-y-6">
 <h1 class="text-2xl font-bold">Thống kê đọc sách của tôi</h1>
 <p class="text-slate-600">Chỉ hiển thị dữ liệu thuộc tài khoản của bạn.</p>
 <div class="grid sm:grid-cols-4 gap-4">
  @foreach([['Sách đã bắt đầu đọc',$total],['Đang đọc',$reading],['Đã hoàn thành',$finished],['Ghi chú cá nhân',$notesCount]] as [$label,$value])
   <div class="bg-white rounded-lg shadow p-5"><div class="text-sm text-slate-500">{{$label}}</div><div class="text-3xl font-bold mt-2">{{$value}}</div></div>
  @endforeach
 </div>
 <section class="bg-white rounded-lg shadow p-5"><h2 class="font-semibold text-lg mb-4">Tiến độ từng cuốn sách</h2>
 @forelse($progress as $item)
  @php($pages=max(1,$item->book->total_pages)) @php($percent=min(100,round($item->current_page/$pages*100)))
  <div class="py-3 border-b last:border-0"><div class="flex justify-between gap-3"><a class="font-medium text-indigo-700 hover:underline" href="{{route('books.read',$item->book)}}">{{$item->book->title}}</a><span class="text-sm text-slate-600">{{$percent}}% · Trang {{$item->current_page}}/{{$pages}}</span></div><div class="w-full bg-slate-200 rounded h-2 mt-2"><div class="bg-indigo-600 h-2 rounded" style="width:{{$percent}}%"></div></div><div class="text-xs text-slate-500 mt-1">Cập nhật: {{$item->last_read_at?->format('d/m/Y H:i') ?? 'Chưa rõ'}}</div></div>
 @empty <p class="text-slate-500">Bạn chưa bắt đầu đọc cuốn sách nào.</p> @endforelse
 </section>
</div>
@endsection

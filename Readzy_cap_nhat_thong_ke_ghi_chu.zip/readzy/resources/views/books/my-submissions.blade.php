@extends('layouts.app')
@section('title', 'Truyện của tôi - Readzy')

@section('content')
<div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Truyện tôi đã gửi</h1>
    <a href="{{ route('books.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
        + Gửi truyện mới
    </a>
</div>

<div class="bg-white rounded-lg shadow overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-100 text-left">
            <tr>
                <th class="px-4 py-3">Tên truyện</th>
                <th class="px-4 py-3">Thể loại</th>
                <th class="px-4 py-3">Trạng thái</th>
                <th class="px-4 py-3">Ghi chú</th>
                <th class="px-4 py-3">Ngày gửi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($books as $book)
                <tr class="border-t">
                    <td class="px-4 py-3">
                        <a href="{{ route('books.show', $book) }}" class="text-indigo-600 hover:underline">{{ $book->title }}</a>
                    </td>
                    <td class="px-4 py-3">{{ $book->category->name ?? '-' }}</td>
                    <td class="px-4 py-3">
                        @if($book->status === 'pending')
                            <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">Chờ phê duyệt</span>
                        @elseif($book->status === 'approved')
                            <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Đã phê duyệt</span>
                        @else
                            <span class="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">Từ chối</span>
                        @endif
                    </td>
                    <td class="px-4 py-3 text-slate-500">{{ $book->reject_reason ?: '-' }}</td>
                    <td class="px-4 py-3 text-slate-500">{{ $book->created_at->format('d/m/Y') }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-center py-6 text-slate-500">Bạn chưa gửi truyện nào.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-6">{{ $books->links() }}</div>
@endsection

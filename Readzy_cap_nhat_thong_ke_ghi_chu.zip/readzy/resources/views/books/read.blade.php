@extends('layouts.app')
@section('title', 'Đọc: ' . $book->title)

@section('content')
<div class="max-w-3xl mx-auto">
    <div class="flex items-center justify-between mb-4">
        <h1 class="text-xl font-bold">{{ $book->title }}</h1>
        <a href="{{ route('books.show', $book) }}" class="text-sm text-indigo-600 hover:underline">← Quay lại thông tin sách</a>
    </div>

    <div class="bg-white rounded-lg shadow p-6 min-h-[400px] leading-relaxed whitespace-pre-line">
        {{ $content }}
    </div>

    <section class="mt-6 bg-white rounded-lg shadow p-5">
        <h2 class="font-semibold text-lg mb-2">Ghi chú cá nhân</h2>
        <p class="text-sm text-slate-500 mb-3">Chỉ bạn nhìn thấy ghi chú này. Ghi chú được lưu riêng theo tài khoản của bạn cho cuốn sách này.</p>
        <form method="POST" action="{{ route('books.note.save', $book) }}">@csrf @method('PUT')
            <textarea name="note" rows="5" maxlength="20000" class="w-full border rounded p-3" placeholder="Ghi lại suy nghĩ, trích dẫn hoặc điều muốn nhớ...">{{ old('note', $note?->note ?? '') }}</textarea>
            @error('note')<p class="text-red-600 text-sm">{{ $message }}</p>@enderror
            <button class="mt-3 bg-indigo-600 text-white rounded px-4 py-2">Lưu ghi chú riêng</button>
        </form>
    </section>

    <div class="flex items-center justify-between mt-6">
        @if($currentPage > 1)
            <a href="{{ route('books.read.page', [$book, $currentPage - 1]) }}"
               class="bg-slate-200 px-4 py-2 rounded hover:bg-slate-300">← Trang trước</a>
        @else
            <span></span>
        @endif

        <span class="text-sm text-slate-500">Trang {{ $currentPage }} / {{ $totalPages }}</span>

        @if($currentPage < $totalPages)
            <a href="{{ route('books.read.page', [$book, $currentPage + 1]) }}"
               class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Trang sau →</a>
        @else
            <span class="text-sm text-green-600 font-medium">🎉 Bạn đã đọc hết truyện</span>
        @endif
    </div>

    <p class="text-xs text-slate-400 text-center mt-3">
        Tiến độ đọc của bạn được tự động lưu lại mỗi khi chuyển trang.
    </p>
</div>
@endsection

@extends('layouts.app')
@section('title', 'Đăng nhập - Readzy')

@section('content')
<div class="max-w-md mx-auto bg-white p-8 rounded-lg shadow">
    <h1 class="text-2xl font-bold mb-6 text-center">Đăng nhập</h1>

    @if ($errors->any())
        <div class="mb-4 rounded bg-red-100 text-red-700 px-4 py-3 text-sm">
            @foreach ($errors->all() as $error)
                <p>{{ $error }}</p>
            @endforeach
        </div>
    @endif

    <form method="POST" action="{{ route('login') }}" class="space-y-4">
        @csrf
        <div>
            <label class="block text-sm font-medium mb-1">Email</label>
            <input type="email" name="email" value="{{ old('email') }}" required autofocus
                   class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Mật khẩu</label>
            <input type="password" name="password" required
                   class="w-full border rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
        </div>
        <label class="flex items-center gap-2 text-sm">
            <input type="checkbox" name="remember"> Ghi nhớ đăng nhập
        </label>
        <button type="submit" class="w-full bg-indigo-600 text-white py-2 rounded hover:bg-indigo-700">
            Đăng nhập
        </button>
    </form>

    <p class="text-sm text-center mt-4">
        Chưa có tài khoản? <a href="{{ route('register') }}" class="text-indigo-600 hover:underline">Đăng ký ngay</a>
    </p>

    <p class="text-xs text-center mt-4 text-slate-400">
        Demo Admin: admin@readzy.local / password<br>
        Demo User: user@readzy.local / password
    </p>
</div>
@endsection

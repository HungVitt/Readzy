@extends('layouts.app')
@section('title', 'Thêm truyện - Admin')

@section('content')
<div class="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow">
    <h1 class="text-2xl font-bold mb-6">Thêm truyện mới</h1>
    <form method="POST" action="{{ route('admin.books.store') }}" enctype="multipart/form-data">
        @include('admin.books._form')
    </form>
</div>
@endsection

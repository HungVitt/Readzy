@csrf
@if(isset($book))
    @method('PUT')
@endif

@if ($errors->any())
    <div class="mb-4 rounded bg-red-100 text-red-700 px-4 py-3 text-sm">
        @foreach ($errors->all() as $error)
            <p>{{ $error }}</p>
        @endforeach
    </div>
@endif

<div class="space-y-4">
    <div>
        <label class="block text-sm font-medium mb-1">Tên truyện</label>
        <input type="text" name="title" value="{{ old('title', $book->title ?? '') }}" required class="w-full border rounded px-3 py-2">
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Tác giả</label>
        <input type="text" name="author" value="{{ old('author', $book->author ?? '') }}" class="w-full border rounded px-3 py-2">
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Thể loại</label>
        <select name="category_id" class="w-full border rounded px-3 py-2">
            <option value="">-- Chọn thể loại --</option>
            @foreach($categories as $cat)
                <option value="{{ $cat->id }}" @selected(old('category_id', $book->category_id ?? null) == $cat->id)>{{ $cat->name }}</option>
            @endforeach
        </select>
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Ảnh bìa</label>
        <input type="file" name="cover" accept="image/*" class="w-full border rounded px-3 py-2">
        @if(!empty($book?->cover_path))
            <img src="{{ asset('storage/' . $book->cover_path) }}" class="h-20 mt-2 rounded">
        @endif
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Mô tả</label>
        <textarea name="description" rows="3" class="w-full border rounded px-3 py-2">{{ old('description', $book->description ?? '') }}</textarea>
    </div>
    <div>
        <label class="block text-sm font-medium mb-1">Nội dung truyện</label>
        <textarea name="content" rows="12" required class="w-full border rounded px-3 py-2">{{ old('content', $book->content ?? '') }}</textarea>
    </div>

    <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700">
        {{ isset($book) ? 'Cập nhật' : 'Thêm mới' }}
    </button>
</div>

@extends('layouts.app')
@section('title', 'Quản lý sách - Admin')

@section('content')
<div class="flex items-center justify-between mb-6">
    <h1 class="text-2xl font-bold">Quản lý truyện</h1>
    <a href="{{ route('admin.books.create') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
        + Thêm truyện
    </a>
</div>

<form method="GET" class="flex flex-wrap gap-3 mb-4">
    <input type="text" name="q" value="{{ request('q') }}" placeholder="Tìm theo tên / tác giả"
           class="border rounded px-3 py-2 flex-1 min-w-[200px]">
    <select name="status" class="border rounded px-3 py-2">
        <option value="">Tất cả trạng thái</option>
        <option value="pending" @selected(request('status')==='pending')>Chờ phê duyệt</option>
        <option value="approved" @selected(request('status')==='approved')>Đã phê duyệt</option>
        <option value="rejected" @selected(request('status')==='rejected')>Từ chối</option>
    </select>
    <button class="bg-slate-700 text-white px-4 py-2 rounded hover:bg-slate-800">Lọc</button>
</form>

<div class="bg-white rounded-lg shadow overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-100 text-left">
            <tr>
                <th class="px-4 py-3">Tên truyện</th>
                <th class="px-4 py-3">Người gửi</th>
                <th class="px-4 py-3">Thể loại</th>
                <th class="px-4 py-3">Trạng thái</th>
                <th class="px-4 py-3 text-right">Hành động</th>
            </tr>
        </thead>
        <tbody>
            @forelse($books as $book)
                <tr class="border-t align-top">
                    <td class="px-4 py-3">{{ $book->title }}</td>
                    <td class="px-4 py-3 text-slate-500">{{ $book->submitter->name ?? '-' }}</td>
                    <td class="px-4 py-3 text-slate-500">{{ $book->category->name ?? '-' }}</td>
                    <td class="px-4 py-3">
                        @if($book->status === 'pending')
                            <span class="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">Chờ phê duyệt</span>
                        @elseif($book->status === 'approved')
                            <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Đã phê duyệt</span>
                        @else
                            <span class="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">Từ chối</span>
                        @endif
                    </td>
                    <td class="px-4 py-3 text-right space-x-2 whitespace-nowrap">
                        @if($book->status === 'pending')
                            <form action="{{ route('admin.books.approve', $book) }}" method="POST" class="inline">
                                @csrf
                                <button class="text-green-600 hover:underline">Duyệt</button>
                            </form>
                            <form action="{{ route('admin.books.reject', $book) }}" method="POST" class="inline"
                                  onsubmit="return confirm('Từ chối truyện này?')">
                                @csrf
                                <button class="text-red-600 hover:underline">Từ chối</button>
                            </form>
                        @endif
                        <a href="{{ route('admin.books.edit', $book) }}" class="text-indigo-600 hover:underline">Sửa</a>
                        <form action="{{ route('admin.books.destroy', $book) }}" method="POST" class="inline"
                              onsubmit="return confirm('Xóa truyện này?')">
                            @csrf @method('DELETE')
                            <button class="text-red-600 hover:underline">Xóa</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-center py-6 text-slate-500">Không có truyện nào.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-6">{{ $books->links() }}</div>
@endsection

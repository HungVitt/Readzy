@extends('layouts.app')
@section('title', 'Quản lý thể loại - Admin')

@section('content')
<h1 class="text-2xl font-bold mb-6">Quản lý thể loại</h1>

<div class="bg-white p-6 rounded-lg shadow mb-6">
    <form method="POST" action="{{ route('admin.categories.store') }}" class="flex gap-3">
        @csrf
        <input type="text" name="name" placeholder="Tên thể loại mới" required class="border rounded px-3 py-2 flex-1">
        <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Thêm</button>
    </form>
    @error('name')
        <p class="text-red-600 text-sm mt-2">{{ $message }}</p>
    @enderror
</div>

<div class="bg-white rounded-lg shadow overflow-x-auto">
    <table class="w-full text-sm">
        <thead class="bg-slate-100 text-left">
            <tr>
                <th class="px-4 py-3">Tên thể loại</th>
                <th class="px-4 py-3">Số truyện</th>
                <th class="px-4 py-3 text-right">Hành động</th>
            </tr>
        </thead>
        <tbody>
            @forelse($categories as $cat)
                <tr class="border-t">
                    <td class="px-4 py-3">
                        <form action="{{ route('admin.categories.update', $cat) }}" method="POST" class="flex gap-2">
                            @csrf @method('PUT')
                            <input type="text" name="name" value="{{ $cat->name }}" class="border rounded px-2 py-1">
                            <button class="text-indigo-600 hover:underline text-xs">Lưu</button>
                        </form>
                    </td>
                    <td class="px-4 py-3">{{ $cat->books_count }}</td>
                    <td class="px-4 py-3 text-right">
                        <form action="{{ route('admin.categories.destroy', $cat) }}" method="POST"
                              onsubmit="return confirm('Xóa thể loại này?')">
                            @csrf @method('DELETE')
                            <button class="text-red-600 hover:underline">Xóa</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="3" class="text-center py-6 text-slate-500">Chưa có thể loại nào.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<div class="mt-6">{{ $categories->links() }}</div>
@endsection

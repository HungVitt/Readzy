@extends('layouts.app')
@section('title', 'Quản trị - Readzy')

@section('content')
<h1 class="text-2xl font-bold mb-6">Bảng điều khiển Admin</h1>

<div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
    <div class="bg-white p-4 rounded-lg shadow">
        <p class="text-sm text-slate-500">Tổng số truyện</p>
        <p class="text-2xl font-bold">{{ $stats['total_books'] }}</p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <p class="text-sm text-slate-500">Chờ phê duyệt</p>
        <p class="text-2xl font-bold text-yellow-600">{{ $stats['pending_books'] }}</p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <p class="text-sm text-slate-500">Đã phê duyệt</p>
        <p class="text-2xl font-bold text-green-600">{{ $stats['approved_books'] }}</p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <p class="text-sm text-slate-500">Bị từ chối</p>
        <p class="text-2xl font-bold text-red-600">{{ $stats['rejected_books'] }}</p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <p class="text-sm text-slate-500">Người dùng</p>
        <p class="text-2xl font-bold">{{ $stats['total_users'] }}</p>
    </div>
    <div class="bg-white p-4 rounded-lg shadow">
        <p class="text-sm text-slate-500">Thể loại</p>
        <p class="text-2xl font-bold">{{ $stats['total_categories'] }}</p>
    </div>
</div>

<div class="flex gap-3 mb-8">
    <a href="{{ route('admin.books.index') }}" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">Quản lý sách</a>
    <a href="{{ route('admin.categories.index') }}" class="bg-slate-600 text-white px-4 py-2 rounded hover:bg-slate-700">Quản lý thể loại</a>
</div>

<div class="bg-white rounded-lg shadow">
    <div class="px-4 py-3 border-b font-semibold">Truyện đang chờ phê duyệt gần đây</div>
    <table class="w-full text-sm">
        <tbody>
            @forelse($recentPending as $book)
                <tr class="border-t">
                    <td class="px-4 py-3">{{ $book->title }}</td>
                    <td class="px-4 py-3 text-slate-500">{{ $book->created_at->diffForHumans() }}</td>
                    <td class="px-4 py-3 text-right">
                        <a href="{{ route('admin.books.index', ['status' => 'pending']) }}" class="text-indigo-600 hover:underline">Xem &amp; duyệt</a>
                    </td>
                </tr>
            @empty
                <tr><td class="px-4 py-4 text-slate-500">Không có truyện nào đang chờ.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection

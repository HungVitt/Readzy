<?php

namespace Database\Seeders;

use App\Models\Book;
use App\Models\Category;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Tai khoan Admin mac dinh
        $admin = User::firstOrCreate(
            ['email' => 'admin@readzy.local'],
            [
                'name' => 'Admin Readzy',
                'password' => Hash::make('password'),
                'role' => 'admin',
            ]
        );

        // Tai khoan user demo
        $user = User::firstOrCreate(
            ['email' => 'user@readzy.local'],
            [
                'name' => 'Doc Gia Demo',
                'password' => Hash::make('password'),
                'role' => 'user',
            ]
        );

        // The loai mau
        $categories = collect(['Ngôn tình', 'Kiếm hiệp', 'Trinh thám', 'Kinh dị', 'Khoa học viễn tưởng'])
            ->map(fn ($name) => Category::firstOrCreate(['name' => $name]));

        // Sach mau da duoc duyet
        if (Book::count() === 0) {
            Book::create([
                'title' => 'Hành Trình Về Phương Đông',
                'author' => 'Nguyên Phong',
                'category_id' => $categories->first()->id,
                'description' => 'Câu chuyện về hành trình khám phá những bí ẩn phương Đông của một đoàn khoa học gia phương Tây.',
                'content' => str_repeat('Đây là nội dung mẫu của cuốn sách, dùng để minh hoạ tính năng đọc truyện theo trang. ', 200),
                'status' => 'approved',
                'submitted_by' => $admin->id,
            ]);

            Book::create([
                'title' => 'Nhật Ký Trong Tù',
                'author' => 'Hồ Chí Minh',
                'category_id' => $categories->last()->id,
                'description' => 'Tập thơ chữ Hán được viết trong thời gian bị giam giữ.',
                'content' => str_repeat('Nội dung minh hoạ cho cuốn sách thứ hai trong hệ thống Readzy. ', 200),
                'status' => 'approved',
                'submitted_by' => $admin->id,
            ]);

            Book::create([
                'title' => 'Truyện Đang Chờ Duyệt (demo)',
                'author' => 'Doc Gia Demo',
                'category_id' => $categories->get(1)->id,
                'description' => 'Truyện demo do user gửi lên, đang chờ admin phê duyệt.',
                'content' => 'Nội dung truyện demo đang chờ duyệt...',
                'status' => 'pending',
                'submitted_by' => $user->id,
            ]);
        }
    }
}

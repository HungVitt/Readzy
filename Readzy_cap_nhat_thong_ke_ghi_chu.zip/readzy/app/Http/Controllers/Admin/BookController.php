<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;

class BookController extends Controller
{
    /**
     * Danh sach toan bo sach, loc theo trang thai - dung de Admin theo doi.
     */
    public function index(Request $request)
    {
        $books = Book::with(['category', 'submitter'])
            ->when($request->get('status'), fn ($q, $status) => $q->where('status', $status))
            ->search($request->get('q'))
            ->latest()
            ->paginate(15)
            ->withQueryString();

        return view('admin.books.index', compact('books'));
    }

    public function create()
    {
        $categories = Category::orderBy('name')->get();

        return view('admin.books.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $data = $this->validateData($request);

        if ($request->hasFile('story_file')) {
            $data['story_file_path'] = $request->file('story_file')->store('stories', 'public');
        }
        if ($request->hasFile('cover')) {
            $data['cover_path'] = $request->file('cover')->store('covers', 'public');
        }

        // Admin them truc tiep thi duyet luon
        $data['status'] = 'approved';
        $data['submitted_by'] = $request->user()->id;

        Book::create($data);

        return redirect()->route('admin.books.index')->with('success', 'Đã thêm sách mới.');
    }

    public function edit(Book $book)
    {
        $categories = Category::orderBy('name')->get();

        return view('admin.books.edit', compact('book', 'categories'));
    }

    public function update(Request $request, Book $book)
    {
        $data = $this->validateData($request);

        if ($request->hasFile('story_file')) {
            $data['story_file_path'] = $request->file('story_file')->store('stories', 'public');
        }
        if ($request->hasFile('cover')) {
            $data['cover_path'] = $request->file('cover')->store('covers', 'public');
        }

        $book->update($data);

        return redirect()->route('admin.books.index')->with('success', 'Đã cập nhật sách.');
    }

    public function destroy(Book $book)
    {
        $book->delete();

        return back()->with('success', 'Đã xóa sách.');
    }

    /**
     * Admin phe duyet sach do user gui.
     */
    public function approve(Book $book)
    {
        $book->update(['status' => 'approved', 'reject_reason' => null]);

        return back()->with('success', "Đã phê duyệt \"{$book->title}\".");
    }

    /**
     * Admin tu choi sach, co the ghi ly do.
     */
    public function reject(Request $request, Book $book)
    {
        $data = $request->validate([
            'reject_reason' => ['nullable', 'string', 'max:255'],
        ]);

        $book->update([
            'status' => 'rejected',
            'reject_reason' => $data['reject_reason'] ?? 'Không đạt yêu cầu nội dung.',
        ]);

        return back()->with('success', "Đã từ chối \"{$book->title}\".");
    }

    private function validateData(Request $request): array
    {
        return $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'author' => ['nullable', 'string', 'max:255'],
            'category_id' => ['nullable', 'exists:categories,id'],
            'description' => ['nullable', 'string'],
            'content' => ['nullable', 'string'],
            'story_file' => ['nullable', 'file', 'mimes:doc,docx,pdf', 'max:20480'],
            'cover' => ['nullable', 'image', 'max:2048'],
        ]);
    }
}

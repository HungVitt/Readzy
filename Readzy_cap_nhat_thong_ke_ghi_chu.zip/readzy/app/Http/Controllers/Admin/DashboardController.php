<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Book;
use App\Models\Category;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_books' => Book::count(),
            'pending_books' => Book::where('status', 'pending')->count(),
            'approved_books' => Book::where('status', 'approved')->count(),
            'rejected_books' => Book::where('status', 'rejected')->count(),
            'total_users' => User::where('role', 'user')->count(),
            'total_categories' => Category::count(),
        ];

        $recentPending = Book::where('status', 'pending')->latest()->take(5)->get();

        return view('admin.dashboard', compact('stats', 'recentPending'));
    }
}

<?php
namespace App\Http\Controllers;
use App\Models\Book;
use Illuminate\Http\Request;
class BookReviewController extends Controller
{
 public function store(Request $request, Book $book)
 {
  abort_unless($book->status === 'approved', 404);
  $data=$request->validate(['rating'=>['required','integer','between:1,5'],'comment'=>['nullable','string','max:2000']]);
  $book->reviews()->updateOrCreate(['user_id'=>$request->user()->id],$data);
  return back()->with('success','Đã lưu đánh giá của bạn.');
 }
}

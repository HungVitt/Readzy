<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\ReadingProgress;
use App\Models\ReadingNote;
use Illuminate\Http\Request;

class ReadingController extends Controller
{
    /**
     * Man hinh doc truyen - yeu cau dang nhap.
     */
    public function read(Request $request, Book $book, ?int $page = null)
    {
        if ($book->status !== 'approved') {
            abort(404);
        }

        $totalPages = $book->total_pages;

        $progress = ReadingProgress::firstOrNew([
            'user_id' => $request->user()->id,
            'book_id' => $book->id,
        ]);

        // Neu khong truyen so trang tren URL -> tiep tuc tu vi tri da luu
        $currentPage = $page ?? ($progress->current_page ?: 1);
        $currentPage = max(1, min($currentPage, $totalPages));

        $content = $book->getPageContent($currentPage);

        // Luu lai tien do moi lan doc trang
        $progress->current_page = $currentPage;
        $progress->last_read_at = now();
        $progress->save();

        return view('books.read', [
            'book' => $book,
            'content' => $content,
            'currentPage' => $currentPage,
            'totalPages' => $totalPages,
            'note' => ReadingNote::where('user_id', $request->user()->id)->where('book_id', $book->id)->first(),
        ]);
    }

    /**
     * Luu tien do doc qua AJAX (vi du khi nguoi dung cuon trang / bam nut).
     */
    public function updateProgress(Request $request, Book $book)
    {
        $data = $request->validate([
            'current_page' => ['required', 'integer', 'min:1'],
        ]);

        $currentPage = min($data['current_page'], $book->total_pages);

        ReadingProgress::updateOrCreate(
            ['user_id' => $request->user()->id, 'book_id' => $book->id],
            ['current_page' => $currentPage, 'last_read_at' => now()]
        );

        return response()->json(['status' => 'ok', 'current_page' => $currentPage]);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class BookController extends Controller
{
    /**
     * Trang danh sach sach - ai cung xem duoc (khach + user), chi hien sach da duyet.
     */
    public function index(Request $request)
    {
        $books = Book::approved()
            ->search($request->get('q'))
            ->when($request->get('category'), fn ($q, $cat) => $q->where('category_id', $cat))
            ->latest()
            ->paginate(12)
            ->withQueryString();

        $categories = Category::orderBy('name')->get();

        return view('books.index', compact('books', 'categories'));
    }

    /**
     * Trang chi tiet thong tin sach.
     */
    public function show(Book $book)
    {
        // Neu sach chua duoc duyet: chi admin hoac chinh nguoi gui moi xem duoc
        if ($book->status !== 'approved') {
            $user = auth()->user();
            $isOwner = $user && $user->id === $book->submitted_by;
            if (! $user || (! $user->isAdmin() && ! $isOwner)) {
                abort(404);
            }
        }

        $progress = $book->progressFor(auth()->user());
        $book->load(['reviews.user']);
        $averageRating = round((float) $book->reviews()->avg('rating'), 1);
        $myReview = auth()->user() ? $book->reviews()->where('user_id', auth()->id())->first() : null;

        return view('books.show', compact('book', 'progress', 'averageRating', 'myReview'));
    }

    /**
     * Form gui sach moi (yeu cau dang nhap).
     */
    public function create()
    {
        $categories = Category::orderBy('name')->get();

        return view('books.submit', compact('categories'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'author' => ['nullable', 'string', 'max:255'],
            'category_id' => ['nullable', 'exists:categories,id'],
            'description' => ['nullable', 'string'],
            'content' => ['nullable', 'string', 'required_without:story_file'],
            'story_file' => ['nullable', 'file', 'mimes:doc,docx,pdf', 'max:20480', 'required_without:content'],
            'cover' => ['nullable', 'image', 'max:2048'],
        ]);

        if ($request->hasFile('cover')) {
            $data['cover_path'] = $request->file('cover')->store('covers', 'public');
        }

        if ($request->hasFile('story_file')) {
            $data['story_file_path'] = $request->file('story_file')->store('stories', 'public');
        }
        $data['status'] = 'pending';
        $data['submitted_by'] = $request->user()->id;

        Book::create($data);

        return redirect()->route('books.my')->with('success', 'Đã gửi truyện, vui lòng chờ Admin phê duyệt.');
    }

    /**
     * Danh sach truyen nguoi dung da gui + trang thai.
     */
    public function mySubmissions(Request $request)
    {
        $books = $request->user()->books()->latest()->paginate(10);

        return view('books.my-submissions', compact('books'));
    }
}

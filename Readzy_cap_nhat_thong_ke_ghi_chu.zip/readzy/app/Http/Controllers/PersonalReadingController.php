<?php
namespace App\Http\Controllers;
use App\Models\Book;
use App\Models\ReadingNote;
use App\Models\ReadingProgress;
use Illuminate\Http\Request;
class PersonalReadingController extends Controller {
 public function dashboard(Request $request){$user=$request->user();$progress=ReadingProgress::with('book')->where('user_id',$user->id)->get()->filter(fn($p)=>$p->book && $p->book->status==='approved');$total=$progress->count();$finished=$progress->filter(fn($p)=>$p->current_page >= max(1,$p->book->total_pages))->count();return view('books.personal-dashboard',['progress'=>$progress,'total'=>$total,'finished'=>$finished,'reading'=>$total-$finished,'notesCount'=>ReadingNote::where('user_id',$user->id)->count()]);}
 public function saveNote(Request $request, Book $book){abort_unless($book->status==='approved',404);$data=$request->validate(['note'=>['nullable','string','max:20000']]);$userId=$request->user()->id;if(trim($data['note']??'')===''){ReadingNote::where('user_id',$userId)->where('book_id',$book->id)->delete();}else{ReadingNote::updateOrCreate(['user_id'=>$userId,'book_id'=>$book->id],['note'=>$data['note']]);}return back()->with('success','Ghi chú riêng đã được lưu.');}
}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    // So ky tu moi "trang" khi chia noi dung truyen de doc
    const CHARS_PER_PAGE = 1800;

    protected $fillable = [
        'title',
        'author',
        'category_id',
        'description',
        'cover_path',
        'content',
        'status',       // pending | approved | rejected
        'submitted_by', // user_id, null neu admin tu them
        'reject_reason',
        'story_file_path',
    ];

    public function reviews()
    {
        return $this->hasMany(BookReview::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function submitter()
    {
        return $this->belongsTo(User::class, 'submitted_by');
    }

    public function readingProgress()
    {
        return $this->hasMany(ReadingProgress::class);
    }

    public function scopeApproved($query)
    {
        return $query->where('status', 'approved');
    }

    public function scopeSearch($query, ?string $keyword)
    {
        if (! $keyword) {
            return $query;
        }

        return $query->where(function ($q) use ($keyword) {
            $q->where('title', 'like', "%{$keyword}%")
                ->orWhere('author', 'like', "%{$keyword}%");
        });
    }

    /**
     * Chia noi dung truyen thanh cac "trang" de nguoi doc doc dan.
     */
    public function getPages(): array
    {
        $content = trim((string) $this->content);

        if ($content === '') {
            return [''];
        }

        return array_map('trim', str_split($content, self::CHARS_PER_PAGE));
    }

    public function getTotalPagesAttribute(): int
    {
        return count($this->getPages());
    }

    public function getPageContent(int $page): string
    {
        $pages = $this->getPages();
        $page = max(1, min($page, count($pages)));

        return $pages[$page - 1];
    }

    public function progressFor(?User $user)
    {
        if (! $user) {
            return null;
        }

        return $this->readingProgress()->where('user_id', $user->id)->first();
    }
}

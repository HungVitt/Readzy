<?php

use App\Http\Controllers\Admin\BookController as AdminBookController;
use App\Http\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\BookController;
use App\Http\Controllers\ReadingController;
use App\Http\Controllers\PersonalReadingController;
use Illuminate\Support\Facades\Route;

// ================= Trang public / khach =================
Route::get('/', [BookController::class, 'index'])->name('books.index');
Route::get('/books/{book}', [BookController::class, 'show'])->name('books.show');

// ================= Auth =================
Route::middleware('guest')->group(function () {
    Route::get('/register', [RegisterController::class, 'show'])->name('register');
    Route::post('/register', [RegisterController::class, 'store']);
    Route::get('/login', [LoginController::class, 'show'])->name('login');
    Route::post('/login', [LoginController::class, 'store']);
});
Route::post('/logout', [LoginController::class, 'destroy'])->middleware('auth')->name('logout');

// ================= Khu vuc user da dang nhap =================
Route::middleware('auth')->group(function () {
    Route::get('/submit', [BookController::class, 'create'])->name('books.create');
    Route::post('/submit', [BookController::class, 'store'])->name('books.store');
    Route::post('/books/{book}/reviews', [\App\Http\Controllers\BookReviewController::class, 'store'])->name('books.reviews.store');
    Route::get('/my-books', [BookController::class, 'mySubmissions'])->name('books.my');
    Route::get('/my-reading', [PersonalReadingController::class, 'dashboard'])->name('reading.personal');
    Route::put('/books/{book}/note', [PersonalReadingController::class, 'saveNote'])->name('books.note.save');

    Route::get('/books/{book}/read', [ReadingController::class, 'read'])->name('books.read');
    Route::get('/books/{book}/read/{page}', [ReadingController::class, 'read'])
        ->whereNumber('page')->name('books.read.page');
    Route::post('/books/{book}/progress', [ReadingController::class, 'updateProgress'])->name('books.progress');
});

// ================= Khu vuc Admin =================
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    Route::get('/books', [AdminBookController::class, 'index'])->name('books.index');
    Route::get('/books/create', [AdminBookController::class, 'create'])->name('books.create');
    Route::post('/books', [AdminBookController::class, 'store'])->name('books.store');
    Route::get('/books/{book}/edit', [AdminBookController::class, 'edit'])->name('books.edit');
    Route::put('/books/{book}', [AdminBookController::class, 'update'])->name('books.update');
    Route::delete('/books/{book}', [AdminBookController::class, 'destroy'])->name('books.destroy');
    Route::post('/books/{book}/approve', [AdminBookController::class, 'approve'])->name('books.approve');
    Route::post('/books/{book}/reject', [AdminBookController::class, 'reject'])->name('books.reject');

    Route::get('/categories', [AdminCategoryController::class, 'index'])->name('categories.index');
    Route::post('/categories', [AdminCategoryController::class, 'store'])->name('categories.store');
    Route::put('/categories/{category}', [AdminCategoryController::class, 'update'])->name('categories.update');
    Route::delete('/categories/{category}', [AdminCategoryController::class, 'destroy'])->name('categories.destroy');
});
